Assignment B1: Part 1

READ ME:

This simulation demonstrates the ability of agents to navigate through an obstacle course
filled with mazes, obstacles that are non movable, and obstacles that can move. The
agents can be selected by clicking the left mouse button on a red capsule, and then right clicking in the direction the object must move. Left clicking on more than one object will select more than one capsule. Afterwards, if a destination is set, all capsules selected will move towards that destination. Navigating through the obstacle course can be done by
moving the camera by using the numbers 1-7 on the keyboard. Pressing the space bar will clear all agents currently in a list of agents. Pressing the 'r' key will reset the level. Red objects can be moved by selecting the red object with the left click, and them moving them with up,left,down,and right arrow keys. A and D keys will rotate the object. 